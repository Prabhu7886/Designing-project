const mongoose = require('mongoose');

const patientSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, default: 'patient' },
  name: String,
  contact: String,
  healthRecords: [{ type: mongoose.Schema.Types.ObjectId, ref: 'HealthRecord' }]
});

module.exports = mongoose.model('Patient', patientSchema);

const express = require('express');
const router = express.Router();
const Message = require('../models/Message');

// Route to send a message to a doctor
router.post('/', async (req, res) => {
  const { from, to, content } = req.body;
  try {
    const newMessage = new Message({ from, to, content });
    await newMessage.save();
    res.status(201).json(newMessage);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const DoctorNote = require('../models/DoctorNote');

router.post('/', async (req, res) => {
  const { doctor, patient, note } = req.body;
  try {
    const newDoctorNote = new DoctorNote({ doctor, patient, note });
    await newDoctorNote.save();
    res.status(201).json(newDoctorNote);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/', async (req, res) => {
  try {
    const doctorNotes = await DoctorNote.find().populate('doctor patient');
    res.json(doctorNotes);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;

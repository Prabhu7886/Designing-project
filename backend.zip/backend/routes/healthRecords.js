const express = require('express');
const router = express.Router();
const HealthRecord = require('../models/HealthRecord');

// Get health records for a specific patient
router.get('/:patientId', async (req, res) => {
  try {
    const healthRecords = await HealthRecord.find({ patientId: req.params.patientId });
    res.json(healthRecords);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Create a new health record (doctor only)
router.post('/create', async (req, res) => {
  try {
    const newHealthRecord = new HealthRecord(req.body);
    await newHealthRecord.save();
    res.json({ success: true, healthRecord: newHealthRecord });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Update a health record (doctor only)
router.put('/update/:recordId', async (req, res) => {
  try {
    const updatedRecord = await HealthRecord.findByIdAndUpdate(
      req.params.recordId,
      { details: req.body.details },
      { new: true }
    );
    res.json({ success: true, healthRecord: updatedRecord });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

module.exports = router;

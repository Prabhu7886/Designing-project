
// appointments.js (Route)
const express = require('express');
const router = express.Router();
const Appointment = require('../models/Appointment');

// Create an appointment
router.post('/', (req, res) => {
  const { userId, doctorId, date, time } = req.body;
  
  // Check if the appointment slot is already booked
  Appointment.findOne({ doctorId, date, time })
    .then(existingAppointment => {
      if (existingAppointment) {
        return res.status(400).json({ error: 'This slot is already booked.' });
      }
      
      const newAppointment = new Appointment({
        userId,
        doctorId,
        date,
        time
      });

      newAppointment.save()
        .then(appointment => res.json(appointment))
        .catch(err => res.status(500).json({ error: 'Failed to create appointment.' }));
    });
});

// Update an appointment
router.put('/:id', (req, res) => {
  const { date, time } = req.body;
  
  Appointment.findByIdAndUpdate(req.params.id, { date, time }, { new: true })
    .then(updatedAppointment => res.json(updatedAppointment))
    .catch(err => res.status(500).json({ error: 'Failed to update appointment.' }));
});

// Delete an appointment
router.delete('/:id', (req, res) => {
  Appointment.findByIdAndDelete(req.params.id)
    .then(() => res.json({ success: true }))
    .catch(err => res.status(500).json({ error: 'Failed to delete appointment.' }));
});

module.exports = router;

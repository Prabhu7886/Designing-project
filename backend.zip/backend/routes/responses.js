const express = require('express');
const router = express.Router();
const Response = require('../models/Response');

router.post('/', async (req, res) => {
  const { message, content } = req.body;
  try {
    const newResponse = new Response({ message, content });
    await newResponse.save();
    res.status(201).json(newResponse);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get('/', async (req, res) => {
  try {
    const responses = await Response.find().populate('message');
    res.json(responses);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;

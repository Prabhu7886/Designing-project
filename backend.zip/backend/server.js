const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const userRoutes = require('./routes/users');
const appointmentRoutes = require('./routes/appointments');
const doctorRoutes = require('./routes/doctors');
const patientRoutes = require('./routes/patients');
const messageRoutes = require('./routes/messages');
const responseRoutes = require('./routes/responses');
const healthRecordRoutes = require('./routes/healthRecords');
const articleRoutes = require('./routes/articles');
const doctorNoteRoutes = require('./routes/doctorNotes');
const contactDoctorRoutes = require('./routes/contactDoctor');

const app = express();

mongoose.connect('mongodb://127.0.0.1:27017/clinic', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('MongoDB connected...'))
  .catch(err => console.log('MongoDB connection error:', err));

app.use(cors());
app.use(express.json());

app.use('/api/users', userRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use('/api/doctors', doctorRoutes);
app.use('/api/patients', patientRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/responses', responseRoutes);
app.use('/api/health-records', healthRecordRoutes);
app.use('/api/articles', articleRoutes);
app.use('/api/doctor-notes', doctorNoteRoutes);
app.use('/api/contact-doctor', contactDoctorRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
